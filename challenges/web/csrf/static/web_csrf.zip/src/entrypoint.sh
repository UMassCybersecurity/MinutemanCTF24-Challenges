#!/bin/sh
node /app/app.js