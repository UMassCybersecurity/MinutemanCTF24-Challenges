To run this locally for testing, run `docker compose up`.

See https://docs.docker.com/compose/install/ for installation