#!/bin/bash
nginx
node app.js